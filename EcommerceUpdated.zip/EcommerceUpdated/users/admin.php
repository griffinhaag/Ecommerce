<?php
session_start();
include __DIR__ . '/../components/connect.php';

// Check if the session variable userlogin is set and the userRole is Admin
if (isset($_SESSION['userlogin']) && $_SESSION['userRole'] === 'Admin') {
    // The user is an admin and can access the page
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin Dashboard</title>
	<!-- Include your CSS here if any -->
</head>
<body>
    <p>Welcome, Admin!</p>
    <!-- Your admin page content goes here -->
</body>
</html>
<?php
} else {
    // The user is not an admin or not logged in; redirect to the index or login page
    header('Location: index.php');
	exit();

    // Alternatively, you can use header('Location: index.php'); exit();
}
?>
