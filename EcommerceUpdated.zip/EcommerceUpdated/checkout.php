<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	   <?php include 'components/link.php'; ?>
	<title></title>
</head>
<body>
  <!--- Navbar --->
   <?php include 'components/navbar.php'; ?>
  <!--- End navbar --->
</body>
</html>